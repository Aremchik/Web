import React, { useEffect, useState } from "react";
import "./AdminPage.css";

interface Users {
  id: number;
  name: string;
  email: string;
  password: string;
}

export const AdminPage: React.FC = () => {
  const [data, setData] = useState<Users[]>([]);

  useEffect(() => {
    fetch("https://localhost:7059/home/users")
      .then((response) => {
        return response.json();
      })
      .then((data: Users[]) => {
        setData(data);
      })
      .catch(() => {
        console.log("Ошибка");
      });
  }, []);

  return (
    <div className="home-container">
      <div className="data-container">
        <h3>Активные пользователи</h3>
        <hr />
        {data.map((users) => (
          <div className="user-block">
            <div className="users-text">{users.name}</div>
            <div className="users-text">{users.email}</div>
            <hr />
          </div>
        ))}
      </div>
    </div>
  );
};
