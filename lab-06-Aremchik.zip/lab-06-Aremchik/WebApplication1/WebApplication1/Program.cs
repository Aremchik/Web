

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

builder.Configuration.AddJsonFile("Configs/Config.json");
builder.Configuration.AddIniFile("Configs/Config.ini");
builder.Configuration.AddXmlFile("Configs/Config.xml");

app.MapGet("/", (IConfiguration appConfig) => $"{appConfig["Settings:DatabaseConnectionString"]}");

app.MapGet("/config", (IConfiguration appConfig) => $"{appConfig["Config"]}\n {appConfig["info"]} \n {appConfig["smbd"]} \n {appConfig["smth"]} \n {appConfig["smwhere"]}");

app.Run();
